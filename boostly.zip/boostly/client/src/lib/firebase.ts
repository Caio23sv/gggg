import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "@firebase/auth";
import { getFirestore } from "@firebase/firestore";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCQOgFjAJQljWzBdYVJx41NEURZ4T0e9IU",
  authDomain: "t23-65708.firebaseapp.com",
  projectId: "t23-65708",
  storageBucket: "t23-65708.firebasestorage.app",
  messagingSenderId: "1087084372655",
  appId: "1:1087084372655:web:953cf9784274f7d7a82a5a",
  measurementId: "G-CCF8S0H63G",
  databaseURL: `https://t23-65708-default-rtdb.firebaseio.com`
};

// Inicializa Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const rtdb = getDatabase(app);

// Provedor do Google
const googleProvider = new GoogleAuthProvider();

// Função para login com Google
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error("Erro no login com Google:", error);
    throw error;
  }
};