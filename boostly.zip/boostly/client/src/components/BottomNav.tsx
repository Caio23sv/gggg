
import { Link } from "wouter";
import { HomeIcon, PlusIcon, SearchIcon, UserIcon } from "lucide-react";

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t">
      <div className="flex justify-around items-center h-16">
        <Link href="/">
          <div className="flex flex-col items-center cursor-pointer">
            <HomeIcon className="h-6 w-6" />
            <span className="text-xs">Home</span>
          </div>
        </Link>
        
        <Link href="/search">
          <div className="flex flex-col items-center cursor-pointer">
            <SearchIcon className="h-6 w-6" />
            <span className="text-xs">Search</span>
          </div>
        </Link>

        <Link href="/add">
          <div className="flex flex-col items-center cursor-pointer">
            <PlusIcon className="h-6 w-6" />
            <span className="text-xs">Add</span>
          </div>
        </Link>

        <Link href="/profile">
          <div className="flex flex-col items-center cursor-pointer">
            <UserIcon className="h-6 w-6" />
            <span className="text-xs">Profile</span>
          </div>
        </Link>
      </div>
    </nav>
  );
}
