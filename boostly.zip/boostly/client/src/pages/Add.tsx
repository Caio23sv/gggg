import { Card, CardContent } from "@/components/ui/card";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { auth, rtdb } from "@/lib/firebase";
import { ref, push, serverTimestamp } from "firebase/database";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface AnuncioForm {
  titulo: string;
  preco: string;
  descricao: string;
  imagens: string[];
  lerMais: boolean;
  linkLerMais?: string;
}

export default function Add() {
  const [formData, setFormData] = useState<AnuncioForm>({
    titulo: "",
    preco: "",
    descricao: "",
    imagens: ["", "", ""],
    lerMais: false,
    linkLerMais: ""
  });
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!auth.currentUser) {
      toast({
        title: "Erro",
        description: "Você precisa estar logado para postar um anúncio",
        variant: "destructive"
      });
      setLocation("/profile");
      return;
    }

    try {
      const userName = auth.currentUser.displayName || auth.currentUser.email?.split('@')[0] || 'Usuário';
      const userPhoto = auth.currentUser.photoURL || '';

      const anuncioRef = ref(rtdb, 'anuncios');
      await push(anuncioRef, {
        ...formData,
        imagens: formData.imagens.filter(img => img !== ""),
        userId: auth.currentUser.uid,
        userName: userName,
        userPhoto: userPhoto,
        createdAt: serverTimestamp(),
        curtidas: 0, // Campo para quantidade de curtidas
      });

      toast({
        title: "Sucesso!",
        description: "Seu anúncio foi publicado"
      });

      setLocation("/");
    } catch (error) {
      console.error("Erro ao publicar anúncio:", error);
      toast({
        title: "Erro",
        description: "Não foi possível publicar seu anúncio",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container p-4">
      <Card>
        <CardContent className="p-6">
          <h1 className="text-2xl font-bold mb-6">Criar Anúncio</h1>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="titulo">Título do Anúncio</Label>
              <Input
                id="titulo"
                value={formData.titulo}
                onChange={(e) => setFormData(prev => ({...prev, titulo: e.target.value}))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="preco">Preço</Label>
              <Input
                id="preco"
                value={formData.preco}
                onChange={(e) => setFormData(prev => ({...prev, preco: e.target.value}))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Textarea
                id="descricao"
                value={formData.descricao}
                onChange={(e) => setFormData(prev => ({...prev, descricao: e.target.value}))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>URLs das Imagens (até 3)</Label>
              {formData.imagens.map((url, index) => (
                <Input
                  key={index}
                  value={url}
                  onChange={(e) => {
                    const newImagens = [...formData.imagens];
                    newImagens[index] = e.target.value;
                    setFormData(prev => ({...prev, imagens: newImagens}));
                  }}
                  placeholder={`URL da imagem ${index + 1}`}
                />
              ))}
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="lerMais"
                checked={formData.lerMais}
                onCheckedChange={(checked) => setFormData(prev => ({...prev, lerMais: checked}))}
              />
              <Label htmlFor="lerMais">Adicionar botão "Ler mais"</Label>
            </div>

            {formData.lerMais && (
              <div className="space-y-2">
                <Label htmlFor="linkLerMais">Link "Ler mais"</Label>
                <Input
                  id="linkLerMais"
                  value={formData.linkLerMais}
                  onChange={(e) => setFormData(prev => ({...prev, linkLerMais: e.target.value}))}
                  required
                />
              </div>
            )}

            <Button type="submit" className="w-full">
              Publicar Anúncio
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}