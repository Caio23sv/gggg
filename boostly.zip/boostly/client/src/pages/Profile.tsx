import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import AuthForm from "@/components/auth/AuthForm";
import { auth, db } from "@/lib/firebase";
import { doc, getDoc } from "@firebase/firestore";
import { onAuthStateChanged } from "@firebase/auth";

interface UserProfile {
  name: string;
  bio: string;
  photoUrl: string;
  email: string;
  followers: string[]; // Assuming followers are stored as an array of user IDs
  following: string[]; // Assuming following are stored as an array of user IDs
}

export default function Profile() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const handleLogout = () => {
    auth.signOut().then(() => {
      window.location.href = '/';
    });
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));
          if (userDoc.exists()) {
            setUser(userDoc.data() as UserProfile);
          }
        } catch (error) {
          console.error("Erro ao buscar perfil:", error);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="container p-4">
        <Card>
          <CardContent className="p-6">
            <p>Carregando...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container p-4">
        <AuthForm />
      </div>
    );
  }

  return (
    <div className="container p-4">
      <Card>
        <CardContent className="p-6 flex flex-col items-center relative">
          <div className="absolute top-2 right-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Editar Perfil</DropdownMenuItem>
                <DropdownMenuItem>Preferências</DropdownMenuItem>
                <DropdownMenuItem>Notificações</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-red-600" onClick={handleLogout}>
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <Avatar className="w-24 h-24 mb-4">
            {user.photoUrl ? (
              <AvatarImage src={user.photoUrl} alt={user.name} />
            ) : (
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            )}
          </Avatar>
          <h1 className="text-2xl font-bold mb-2">{user.name}</h1>
          <p className="text-muted-foreground mb-4">{user.email}</p>
          <p className="text-center mb-4">{user.bio}</p>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <span>{user.followers?.length || 0} seguidores</span>
            <span>{user.following?.length || 0} seguindo</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}