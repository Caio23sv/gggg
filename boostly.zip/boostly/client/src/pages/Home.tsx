import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/layouts/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { useState } from "react";

interface Anuncio {
  titulo: string;
  preco: string;
  descricao: string;
  imagens: string[];
  userName: string;
  userPhotoUrl: string;
  createdAt: number;
  curtidas: number; // Campo para guardar a quantidade de curtidas
  curtido: boolean; // Estado que indica se o usuário já curtiu o anúncio
  linkLerMais?: string; // Adicionando o link para "Ler mais"
}

export default function Home() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['home'],
    queryFn: async () => {
      const response = await fetch('/api/home');
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    },
    refetchInterval: 2000, // Atualiza a cada 2 segundos
  });

  const handleLike = async (titulo: string, currCurtidas: number) => {
    const newCurtidas = currCurtidas + 1;

    // Enviar requisição para atualizar as curtidas no banco de dados
    await fetch(`/api/like/${titulo}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ curtidas: newCurtidas }),
    });

    alert(`Você curtiu o anúncio: ${titulo}`);
  };

  if (isLoading) return <div>Carregando anúncios...</div>;
  if (error) return <div>Erro ao carregar os anúncios</div>;

  return (
    <MainLayout>
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4">Anúncios Recentes</h1>
        <div className="grid grid-cols-2 gap-4">
          {data?.anuncios?.length > 0 ? (
            data.anuncios.map((anuncio: Anuncio) => (
              <Card key={anuncio.createdAt} className="relative w-full max-w-sm">
                <CardContent className="p-4">
                  {anuncio.imagens && anuncio.imagens[0] && (
                    <img
                      src={anuncio.imagens[0]}
                      alt={anuncio.titulo}
                      className="w-full h-60 object-cover rounded-lg mb-4"
                    />
                  )}
                  <h2 className="text-xl font-semibold mb-2">{anuncio.titulo}</h2>
                  <div className="flex items-center space-x-2 mb-3">
                    <img
                      src={anuncio.userPhotoUrl || 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'}
                      alt={anuncio.userName}
                      className="w-8 h-8 rounded-full"
                    />
                    <span className="text-sm text-gray-600">{anuncio.userName}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{anuncio.descricao}</p>
                  <p className="text-lg font-bold text-green-600">R$ {anuncio.preco}</p>
                  {anuncio.linkLerMais && (
                    <div className="flex mb-2">
                      <a href={anuncio.linkLerMais} target="_blank" rel="noopener noreferrer" className="text-blue-500">
                        Ver mais
                      </a>
                    </div>
                  )}
                  <div className="flex items-center">
                    <button
                      onClick={() => handleLike(anuncio.titulo, anuncio.curtidas)}
                      className="absolute bottom-2 right-2 text-red-500 text-2xl"
                    >
                      {anuncio.curtido ? '❤️' : '🤍'}
                    </button>
                    <span className="ml-1 text-sm">{anuncio.curtidas}</span>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <p>Nenhum anúncio encontrado</p>
          )}
        </div>
      </div>
    </MainLayout>
  );
}