import { auth } from "@/lib/firebase";
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { doc, updateDoc, arrayUnion } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { collection, getDocs } from "firebase/firestore";
import MainLayout from "@/layouts/MainLayout";


interface User {
  id: string;
  name: string;
  photoUrl: string;
  followers?: string[];
  following?: string[];
}

export default function Search() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentUserData, setCurrentUserData] = useState<any>(null);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setCurrentUserData(user);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    let isMounted = true;
    const fetchUsers = async () => {
      try {
        const usersCollection = collection(db, "users");
        const snapshot = await getDocs(usersCollection);
        if (isMounted) {
          const userData = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          } as User));
          setUsers(userData);
          setLoading(false);
        }
      } catch (error) {
        console.error("Error fetching users:", error);
        if (isMounted) setLoading(false);
      }
    };

    fetchUsers();
    return () => {
      isMounted = false;
    };
  }, []);

  const filteredUsers = users.filter((user) =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="container max-w-2xl mx-auto p-4">
        <input
          type="text"
          placeholder="Search users..."
          className="w-full p-2 mb-4 border rounded"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        {loading ? (
          <p>Carregando usuários...</p>
        ) : (
          <div className="space-y-2">
            {filteredUsers.map((user) => (
              <Card
                key={user.id}
                className="cursor-pointer hover:bg-gray-50"
                onClick={() => window.location.href = `/profile/${user.id}`}
              >
                <CardContent className="p-4 flex items-center space-x-3">
                  <img
                    src={user.photoUrl || 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'}
                    alt={user.name}
                    className="w-10 h-10 rounded-full"
                  />
                  <div className="flex justify-between items-center w-full">
                    <span className="font-medium">{user.name}</span>
                    <Button
                      variant={currentUserData?.following?.includes(user.id) ? "default" : "outline"}
                      size="sm"
                      onClick={async (e) => {
                        e.stopPropagation();
                        if (!currentUserData) return;

                        const userRef = doc(db, "users", user.id);
                        const currentUserRef = doc(db, "users", currentUserData.uid);

                        await updateDoc(userRef, {
                          followers: arrayUnion(currentUserData.uid),
                        });

                        await updateDoc(currentUserRef, {
                          following: arrayUnion(user.id),
                        });
                      }}
                    >
                      {currentUserData?.following?.includes(user.id) ? "Seguindo" : "Seguir"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}