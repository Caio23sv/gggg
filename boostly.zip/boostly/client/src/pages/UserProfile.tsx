
import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { db } from "@/lib/firebase";
import { doc, getDoc } from "@firebase/firestore";
import MainLayout from "@/layouts/MainLayout";

interface UserProfile {
  name: string;
  bio: string;
  photoUrl: string;
  email: string;
  followers: string[];
  following: string[];
}

export default function UserProfile({ params }: { params: { id: string } }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userDoc = await getDoc(doc(db, "users", params.id));
        if (userDoc.exists()) {
          setUser(userDoc.data() as UserProfile);
        }
      } catch (error) {
        console.error("Erro ao buscar perfil:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [params.id]);

  if (loading) {
    return (
      <MainLayout>
        <div className="container p-4">
          <p>Carregando...</p>
        </div>
      </MainLayout>
    );
  }

  if (!user) {
    return (
      <MainLayout>
        <div className="container p-4">
          <p>Usuário não encontrado</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container p-4">
        <Card>
          <CardContent className="p-6 flex flex-col items-center">
            <Avatar className="w-24 h-24 mb-4">
              {user.photoUrl ? (
                <AvatarImage src={user.photoUrl} alt={user.name} />
              ) : (
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              )}
            </Avatar>
            <h1 className="text-2xl font-bold mb-2">{user.name}</h1>
            <p className="text-muted-foreground mb-4">{user.email}</p>
            <p className="text-center mb-4">{user.bio}</p>
            <div className="flex gap-4 text-sm text-muted-foreground">
              <span>{user.followers?.length || 0} seguidores</span>
              <span>{user.following?.length || 0} seguindo</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
