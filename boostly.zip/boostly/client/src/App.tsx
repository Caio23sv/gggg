import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence } from "framer-motion";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./lib/firebase";
import { useState, useEffect } from "react";
import MainLayout from "@/layouts/MainLayout";
import PageTransition from "@/components/PageTransition";
import Home from "@/pages/Home";
import Search from "@/pages/Search";
import Add from "@/pages/Add";
import Profile from "@/pages/Profile";
import NotFound from "@/pages/not-found";
import UserProfile from "@/pages/UserProfile";

export default function App() {
  const [location] = useLocation();
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <MainLayout>
        <AnimatePresence mode="wait" initial={false}>
          <Switch key={location}>
            <Route path="/" component={Home} />
            <Route path="/search">
              {() => <Search currentUser={currentUser} />}
            </Route>
            <Route path="/add" component={Add} />
            <Route path="/profile" component={Profile} />
            <Route path="/profile/:id" component={UserProfile} />
            <Route component={NotFound} />
          </Switch>
        </AnimatePresence>
      </MainLayout>
      <Toaster />
    </QueryClientProvider>
  );
}