import type { Express } from "express";
import { createServer, type Server } from "http";
import { ref, get, set } from "firebase/database";
import { rtdb } from '../client/src/lib/firebase';

export function registerRoutes(app: Express): Server {
  app.get('/api/home', async (_req, res) => {
    try {
      const anunciosRef = ref(rtdb, 'anuncios');
      const snapshot = await get(anunciosRef);
      const anuncios = snapshot.val() || {};

      const anunciosArray = Object.values(anuncios);
      res.json({ anuncios: anunciosArray });
    } catch (error) {
      console.error('Erro ao buscar anúncios:', error);
      res.status(500).json({ message: 'Erro ao buscar anúncios' });
    }
  });

  app.post('/api/like/:titulo', async (req, res) => {
    const { titulo } = req.params;
    const { curtidas } = req.body;

    try {
      const anuncioRef = ref(rtdb, `anuncios/${titulo}`);

      // Atualiza as curtidas no banco de dados
      await set(anuncioRef, { curtidas });

      res.status(200).json({ message: 'Curtida atualizada' });
    } catch (error) {
      console.error('Erro ao atualizar curtida:', error);
      res.status(500).json({ message: 'Erro ao atualizar curtida' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}